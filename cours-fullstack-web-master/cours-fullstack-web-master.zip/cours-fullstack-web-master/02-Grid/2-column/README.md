# Column

## Mdn:
https://developer.mozilla.org/fr/docs/Web/CSS/grid-column

## W3School:
https://www.w3schools.com/cssref/pr_grid-column.asp
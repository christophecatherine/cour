# Area

## Mdn:
https://developer.mozilla.org/fr/docs/Web/CSS/grid-area

## W3School:
https://www.w3schools.com/cssref/pr_grid-area.asp
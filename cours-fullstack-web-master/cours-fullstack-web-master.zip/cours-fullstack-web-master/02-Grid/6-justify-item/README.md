# Area

## Mdn:
https://developer.mozilla.org/fr/docs/Web/CSS/justify-items

## Css-tricks:
https://css-tricks.com/snippets/css/complete-guide-grid/#:~:text=justify%2Ditems,grid%20items%20inside%20the%20container.
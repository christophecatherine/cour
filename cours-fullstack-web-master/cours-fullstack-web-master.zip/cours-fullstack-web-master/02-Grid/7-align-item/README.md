# Area

## Mdn:
https://developer.mozilla.org/fr/docs/Web/CSS/align-items

## Css-tricks:
https://css-tricks.com/snippets/css/complete-guide-grid/#:~:text=align%2Ditems,start%20edge%20of%20their%20cell
# Display (flex)

Ce tuto démontre les bases de flex

## Doc MDN
https://developer.mozilla.org/fr/docs/Web/CSS/flex

## W3School
https://www.w3schools.com/css/css3_flexbox.asp
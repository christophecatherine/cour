# flex direction

Ce tuto démontre les bases de flex

## Doc MDN
https://developer.mozilla.org/fr/docs/Web/CSS/flex-direction

## W3School
https://www.w3schools.com/cssref/css3_pr_flex-direction.asp
# Justify content

Ce tuto démontre les bases de flex

## Doc MDN
https://developer.mozilla.org/fr/docs/Web/CSS/justify-content

## W3School
https://www.w3schools.com/cssref/css3_pr_justify-content.asp
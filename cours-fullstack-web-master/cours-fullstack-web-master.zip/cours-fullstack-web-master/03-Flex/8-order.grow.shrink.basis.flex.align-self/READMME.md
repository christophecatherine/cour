# Order Grow Shrink Basis flex align-self

Ce tuto démontre les bases de flex

## Doc MDN
https://www.w3schools.com/cssref/css3_pr_align-content.asp

## W3School
https://www.w3schools.com/cssref/css3_pr_flex-shrink.asp
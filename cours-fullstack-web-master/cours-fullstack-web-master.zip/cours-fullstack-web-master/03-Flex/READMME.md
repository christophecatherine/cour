# Tuto Flex

Ce tuto démontre les bases de flex

## tuto flex de la-cascade.io
https://la-cascade.io/flexbox-guide-complet/

## Doc MDN
https://developer.mozilla.org/fr/docs/Web/CSS/flex-wrap

## important !
https://developer.mozilla.org/fr/docs/Web/CSS/align-content#Résultat
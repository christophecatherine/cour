# Variable SASS

## run sass
```
cd 04-Sass/1-variable
sass --watch ./sass/style.sass:./sass/style.css
```

## Doc
https://sass-lang.com/documentation/variables

Drk
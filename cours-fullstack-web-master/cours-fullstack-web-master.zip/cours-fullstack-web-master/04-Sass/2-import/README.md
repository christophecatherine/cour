# Import SASS

## run sass
```
cd 04-Sass/2-import
sass --watch ./sass/style.sass:./sass/style.css
```

## Doc
https://sass-lang.com/documentation/at-rules/import

Drk
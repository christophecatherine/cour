# Partial SASS

## run sass
```
cd 04-Sass/4-partial
sass --watch ./sass/style.sass:./sass/style.css
```

## Doc
https://sass-lang.com/documentation/at-rules/import

Drk
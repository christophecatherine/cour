# Nesting SASS

## run sass
```
cd 04-Sass/5-nesting
sass --watch ./sass/style.sass:./sass/style.css
```

## Doc
https://www.w3schools.com/sass/sass_nesting.asp

Drk
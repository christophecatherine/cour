# Fonction SASS

## run sass
```
cd 04-Sass/6-fonction
sass --watch ./sass/style.sass:./sass/style.css
```

## Doc
https://sass-lang.com/documentation/at-rules/function

Drk
# Boucle SASS

## run sass
```
cd 04-Sass/7-boucle
sass --watch ./sass/style.sass:./sass/style.css
```

## Doc
https://sass-lang.com/documentation/at-rules/control/for
https://sass-lang.com/documentation/at-rules/control/each

Drk
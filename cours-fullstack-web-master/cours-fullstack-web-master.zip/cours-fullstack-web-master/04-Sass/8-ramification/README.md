# Ramification SASS

## run sass
```
cd 04-Sass/8-ramification
sass --watch ./sass/style.sass:./sass/style.css
```

!! Il y a un problème d'image !!

## Doc
https://www.ionos.fr/digitalguide/sites-internet/developpement-web/sass-tutoriel/#c179513

Drk
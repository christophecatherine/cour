# Tuto SASS

Ce tuto va vous permettre de comprendre les bases de sass

## Install Sass (DigitalOcean)

source:
https://www.digitalocean.com/community/tutorials/how-to-set-up-sass-on-your-vps-running-on-ubuntu

https://sass-lang.com/guide

Tuto récupéré ici
https://www.ionos.fr/digitalguide/sites-internet/developpement-web/sass-tutoriel/

## run sass
Example:
```
cd 04-Sass/1-variable
sass --watch ./sass/style.sass:./sass/style.css
```

Drk
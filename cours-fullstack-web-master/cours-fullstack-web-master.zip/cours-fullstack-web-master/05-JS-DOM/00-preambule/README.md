# DOC OFFICIELLE JAVASCRIPT

- https://developer.mozilla.org/fr/docs/Web/JavaScript/Guide/Types_et_grammaire

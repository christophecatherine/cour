# JS - Noeuds

# Docs
https://developer.mozilla.org/fr/docs/Apprendre/JavaScript/Client-side_web_APIs/Manipulating_documents#Cr%C3%A9er_et_placer_de_nouveaux_noeuds
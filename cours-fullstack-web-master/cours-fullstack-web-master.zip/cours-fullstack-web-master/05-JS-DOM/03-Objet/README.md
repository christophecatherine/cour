# JS - Objet

## Docs
https://developer.mozilla.org/fr/docs/Learn/JavaScript/Objects/Basics
# JS - Manipulé un json

## Exercice

Rendez-vous sur le site de MDN (lien en dessous)

Et réaliser l'exercice de manipulation d'un Json

## Docs
https://developer.mozilla.org/fr/docs/Learn/JavaScript/Objects/JSON

Et si vous allez un peu plus loin dans le tuto vous pourrez trouver ceci:
  - Conversion entre objets et textes

Ce qui pourra vous aidez par la suite
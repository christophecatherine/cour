# JS - Constructor

## Exercice

## Docs
https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Classes/constructor
https://www.digitalocean.com/community/tutorials/understanding-classes-in-javascript-fr
https://www.w3schools.com/jsref/jsref_constructor_class.asp
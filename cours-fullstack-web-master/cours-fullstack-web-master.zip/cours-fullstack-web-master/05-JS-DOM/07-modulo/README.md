# JS - Modulo

## Exercice

## Docs
https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Op%C3%A9rateurs/Op%C3%A9rateurs_arithm%C3%A9tiques
https://blog.smarchal.com/modulo-en-js
https://www.w3schools.com/js/js_arithmetic.asp
Docs:
  - https://developer.mozilla.org/fr/docs/Web/Guide/HTML/Formulaires/Validation_donnees_formulaire
  - https://developer.mozilla.org/fr/docs/Web/API/Event/preventDefault
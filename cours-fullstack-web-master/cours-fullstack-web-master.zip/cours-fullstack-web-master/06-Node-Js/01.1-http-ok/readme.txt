Doc Officiel de NodeJS
https://nodejs.org/en/docs/guides/getting-started-guide/

__________________________________________________________________________________________

Objectif:

Ce tuto à pour objectif de créé un page web (http) via NodeJS

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 1.1-http-ok
        cd 1.1-http-ok
        touch server.js

3- maintenant éditez server.js
        lancer le script avec :
        node server.js

__________________________________________________________________________________________

petit conseil:

Afin de créé une belle architecture de votre dossier je vous conseil de tout créé depuis votre IDE ( Visual code, brackets, komodo edit, ... )

exemple:
    (

        Ce tuto à pour objectif de créé un page web (http) via NodeJS

        1- en premier :
                allez dans un dossier pour créé un projet:
                (exemple:)
                cd /Documents/Dev/exercice/6-Node-Js/

        2- Ensuite créé un dossier:
                mkdir 1.1-http-ok
                cd 1.1-http-ok
                code .
                (créé vos dossier ou fichier depuis votre IDE)

        3- maintenant lancez server.js
                lancer le script avec :
                node server.js
    )
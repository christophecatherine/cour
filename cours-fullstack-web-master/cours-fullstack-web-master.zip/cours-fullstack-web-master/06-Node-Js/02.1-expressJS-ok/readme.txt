Doc Officiel de ExpressJS
https://expressjs.com/fr/starter/hello-world.html

installation du paquet via npm
https://www.npmjs.com/package/express

__________________________________________________________________________________________

Objectif:

Ce tuto à pour objectif de créé un page web (http) via NodeJS et ExpressJS

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 2.1-expressJS-ok
        cd 2.1-expressJS-ok
        mkdir public
        cd public
        touch index.html
        cd ..
        touch server.js
        npm init -y
        npm i express

3- maintenant éditez server.js
        lancer le script avec :
        npm i
        npm start
        
__________________________________________________________________________________________

petit conseil:

Afin de créé une belle architecture de votre dossier je vous conseil de tout créé depuis votre IDE ( Visual code, brackets, komodo edit, ... )

exemple:
    (

        Ce tuto à pour objectif de créé un page web (http) via NodeJS et ExpressJS

        1- en premier :
                allez dans un dossier pour créé un projet:
                (exemple:)
                cd /Documents/Dev/exercice/6-Node-Js/

        2- Ensuite créé un dossier:
                mkdir 2.1-expressJS-ok
                cd 2.1-expressJS-ok
                npm init -y
                npm i express
                code .
                (créé vos dossier ou fichier depuis votre IDE)

        3- maintenant éditez server.js
                lancer le script avec :
                npm i
                npm start
    )
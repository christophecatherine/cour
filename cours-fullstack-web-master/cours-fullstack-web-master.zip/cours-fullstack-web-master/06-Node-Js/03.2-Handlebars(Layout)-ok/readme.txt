Doc Officiel de handlebars
https://handlebarsjs.com/guide/#what-is-handlebars

installation du paquet via npm
https://www.npmjs.com/package/handlebars

__________________________________________________________________________________________

Objectif:

Ce tuto à pour objectif de créé un 2eme Layout pour l'Administration

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 3.1-Handlebars-ok
        cd 3.1-Handlebars-ok
        touch server.js
        npm init -y
        npm i express express-handlebars body-parser
        code .

3- maintenant éditez votre dossier 3.2-Handlebars(Layout)-ok
        lancer le script avec :
        npm start

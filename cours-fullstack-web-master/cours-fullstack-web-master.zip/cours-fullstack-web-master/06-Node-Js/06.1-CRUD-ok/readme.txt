Objectif:
Ce tuto à pour objectif de créé un CRUD sur votre projet
    - Create model
    - Read model
    - Update model
    - Delete model

Lier une base de donnée a notre projet et s'en servir pour créé et administré nos data (user, article, ...)

__________________________________________________________________________________________

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 6.1-CRUD-ok
        cd 6.1-CRUD-ok
        touch server.js
        npm init -y
        npm i express express-handlebars body-parser hbs mongoose
        code .

3- Maintenant éditez votre dossier 6.1-CRUD-ok
        lancer le script avec :
        npm start

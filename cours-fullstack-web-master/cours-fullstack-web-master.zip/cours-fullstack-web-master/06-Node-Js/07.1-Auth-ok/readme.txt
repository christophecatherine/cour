Objectif:
Ce tuto à pour objectif de créé des utilisateur et un script d'authenfication grâce à bcrypt

__________________________________________________________________________________________

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 7.1-Auth-ok
        cd 7.1-Auth-ok
        touch server.js
        npm init -y
        npm i express express-handlebars body-parser hbs mongoose bcrypt
        code .

3- Maintenant éditez votre dossier 7.1-Auth-ok
        lancer le script avec :
        npm start

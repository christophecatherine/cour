Doc Express-session
officiel: https://expressjs.com/fr/advanced/best-practice-security.html
npm: https://www.npmjs.com/package/express-session

Objectif:
Ce tuto à pour objectif de créé une session utilisateur pour créé des rôle. (isAdmin, isModo par exemple)

__________________________________________________________________________________________

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 8.1-Session-ok
        cd 8.1-Session-ok
        touch server.js
        npm init -y
        npm i express express-handlebars body-parser hbs mongoose bcrypt express-session
        code .

3- Maintenant éditez votre dossier 8.1-Session-ok
        lancer le script avec :
        npm start

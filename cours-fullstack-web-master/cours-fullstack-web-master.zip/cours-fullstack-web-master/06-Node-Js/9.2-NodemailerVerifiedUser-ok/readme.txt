Doc Officiel de NodeMailer
https://nodemailer.com/about/

depot NPM
https://www.npmjs.com/package/nodemailer

Objectif:
L'exercice sera de pouvoir envoyer un mail depuis votre application sur une boite mail au hasar.

Plus tard nous veront l'exercice de récupération de mail

ensuite le mot de passe oublier

et ensuite faire vérifier son email pour un accès plus complet à votre application

__________________________________________________________________________________________

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 9.2-NodemailerVerifiedUser-ok
        cd 9.2-NodemailerVerifiedUser-ok
        touch server.js
        npm init -y
        npm i express express-handlebars body-parser hbs mongoose bcrypt express-session nodemailer
        code .

3- Maintenant éditez votre dossier 9.2-NodemailerVerifiedUser-ok
        lancer le script avec :
        npm start

Objectif:
L'exercice sera de pouvoir créé et intégré notre css ou sass

__________________________________________________________________________________________

1- en premier :
        allez dans un dossier pour créé un projet:
        (exemple:)
        cd /Documents/Dev/exercice/6-Node-Js/

2- Ensuite créé un dossier:
        mkdir 99.00-End
        cd 99.00-End
        touch server.js
        npm init -y
        npm i express express-handlebars body-parser hbs mongoose bcrypt express-session nodemailer
        code .

3- Maintenant éditez votre dossier 99.00-End
        lancer le script avec :
        npm start

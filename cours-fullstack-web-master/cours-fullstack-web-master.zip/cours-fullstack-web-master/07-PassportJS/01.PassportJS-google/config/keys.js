module.exports = {
    google: {
        clientID: "820761777777-8lsnpni44irps57h6bknupt68jnjsrba.apps.googleusercontent.com",
        clientSecret: "kgHjemAaxFObGF4DYPBkJqzd"
    },
    mongodb: {
        DbLocal: "mongodb://localhost/test",
        DbCloud: "mongodb+srv://drk:drk$@cluster0-z5xrj.mongodb.net/tuto?retryWrites=true&w=majority"
    },
    session: {
        cookieName: 'Pti Biscuit',
        secret: 'securite',
        keys: 'auth'
    }
}
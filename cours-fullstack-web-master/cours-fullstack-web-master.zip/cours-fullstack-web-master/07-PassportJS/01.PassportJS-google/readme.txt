lien du tuto youtube (playlist):
https://www.youtube.com/watch?v=sakQbeRjgwg&list=PL4cUxeGkcC9jdm7QX143aMLAqyM-jTZ2x

err :
si pas de pasword il créé quand quand meme conflit passportjs